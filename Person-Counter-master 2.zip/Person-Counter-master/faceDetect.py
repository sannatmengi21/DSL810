from __future__ import print_function
from imutils import paths
import numpy as np
import argparse
import imutils
import cv2

face_cascade = cv2.CascadeClassifier('G:\DISA\opencv\sources\data\haarcascades\haarcascade_upperbody.xml')

# construct the argument parse and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-i", "--images", required=True, help="path to images directory")
args = vars(ap.parse_args())

# loop over the image paths
for imagePath in paths.list_images(args["images"]):
    img = cv2.imread(imagePath)
    img = imutils.resize(img, width=min(500, img.shape[1]))
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.05, minNeighbors=3)
    for (x,y,w,h) in faces:
        cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
        roi_gray = gray[y:y+h, x:x+w]
        roi_color = img[y:y+h, x:x+w]
        
    # show the output images
    cv2.imshow("frame",img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    

