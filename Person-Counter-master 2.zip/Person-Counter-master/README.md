# personcounter
An opencv project that counts the number of people in a room
